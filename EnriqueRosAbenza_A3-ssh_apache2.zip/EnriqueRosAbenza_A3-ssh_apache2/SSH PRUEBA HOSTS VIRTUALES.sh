SSH PRUEBA HOSTS VIRTUALES 
HOST -> (smr.ros.com Y smr.abenza.com) .confs -> (smr.ros.com.conf Y smr.abenza.com.conf)

ssh usuario@ip
scp usuario@ip:<ruta absoluta> <ruta absoluta de maquina base>