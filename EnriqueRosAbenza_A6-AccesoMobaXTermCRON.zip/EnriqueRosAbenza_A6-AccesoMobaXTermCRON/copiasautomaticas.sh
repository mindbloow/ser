#!/bin/bash
mkdir /home/mindbloow/copias_de_seguridad/$(date +%Y%m%d)_apache_config
cp /etc/apache2/sites-enabled/*.conf /home/mindbloow/copias_de_seguridad/$(date +%Y%m%d)_apache_config
tar cvf /home/mindbloow/copias_de_seguridad/$(date +%Y%m%d)_apache_config.tar.gz /home/mindbloow/copias_de_seguridad/$(date +%Y%m%d)_apache_config
rm -r /home/mindbloow/copias_de_seguridad/$(date +%Y%m%d)_apache_config
